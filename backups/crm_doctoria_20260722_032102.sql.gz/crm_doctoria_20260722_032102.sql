-- MySQL dump 10.13  Distrib 8.4.6, for Linux (x86_64)
--
-- Host: localhost    Database: crm_doctoria
-- ------------------------------------------------------
-- Server version	8.4.6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `antecedentes`
--

DROP TABLE IF EXISTS `antecedentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `antecedentes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expediente_id` int NOT NULL,
  `grupo` enum('patologico','no_patologico') NOT NULL,
  `item_key` varchar(100) NOT NULL,
  `valor` enum('si','no','null') NOT NULL DEFAULT 'null',
  `especificacion` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_exp_item` (`expediente_id`,`item_key`),
  CONSTRAINT `antecedentes_ibfk_1` FOREIGN KEY (`expediente_id`) REFERENCES `expedientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `antecedentes`
--

LOCK TABLES `antecedentes` WRITE;
/*!40000 ALTER TABLE `antecedentes` DISABLE KEYS */;
INSERT INTO `antecedentes` VALUES (1,1,'patologico','diabetes','no',''),(2,1,'patologico','marcapasos','si','Instalado hace 2 años'),(3,1,'no_patologico','embarazo','no','');
/*!40000 ALTER TABLE `antecedentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `doctor_id` int NOT NULL,
  `patient_id` int NOT NULL,
  `created_by` int NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `contact_phone` varchar(40) DEFAULT NULL,
  `status` enum('pending','approved','rejected','completed') NOT NULL DEFAULT 'pending',
  `source_channel` varchar(100) DEFAULT 'crm',
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `reminder_sent` tinyint(1) DEFAULT '0',
  `confirmation_status` varchar(20) DEFAULT 'unconfirmed',
  `confirmation_token` varchar(64) DEFAULT NULL,
  `resource_id` int DEFAULT NULL,
  `doctor_commission_rate` decimal(5,2) DEFAULT '50.00',
  `clinic_id` int DEFAULT '1',
  `is_telemed` tinyint(1) DEFAULT '0',
  `video_room_token` varchar(64) DEFAULT NULL,
  `telemed_status` varchar(20) DEFAULT 'scheduled',
  PRIMARY KEY (`id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `patient_id` (`patient_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`id`),
  CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `users` (`id`),
  CONSTRAINT `appointments_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
INSERT INTO `appointments` VALUES (11,5,'Consulta General #1',2,5,5,'2026-03-10 08:00:00','2026-03-10 08:30:00','+57 300 100 1005','pending','crm','Control clínico','2026-07-11 09:15:27',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(12,6,'Control Mensual #2',3,6,3,'2026-03-10 11:00:00','2026-03-10 11:30:00','+57 300 100 1006','approved','web','Validación de resultados','2026-07-11 09:15:27',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(13,7,'Seguimiento #3',4,7,7,'2026-03-10 14:00:00','2026-03-10 14:30:00','+57 300 100 1007','approved','whatsapp','Dolor persistente','2026-07-11 09:15:27',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(14,8,'Chequeo #4',11,8,11,'2026-03-10 17:00:00','2026-03-10 17:30:00','+57 300 100 1008','approved','chatbot','Chequeo anual','2026-07-11 09:15:27',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(15,9,'Teleconsulta #5',12,9,9,'2026-03-10 20:00:00','2026-03-10 20:30:00','+57 300 100 1009','pending','crm','Consulta rápida','2026-07-11 09:15:27',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(16,10,'Revisión #6',2,10,2,'2026-03-10 23:00:00','2026-03-10 23:30:00','+57 300 100 1010','rejected','web','Revisión integral','2026-07-11 09:15:27',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(17,5,'Consulta Especializada #7',3,5,5,'2026-03-11 02:00:00','2026-03-11 02:30:00','+57 300 100 1005','completed','whatsapp','Control clínico','2026-07-11 09:15:27',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(18,6,'Consulta General #8',4,6,4,'2026-03-11 05:00:00','2026-03-11 05:30:00','+57 300 100 1006','pending','chatbot','Validación de resultados','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(19,7,'Control Mensual #9',11,7,7,'2026-03-11 08:00:00','2026-03-11 08:30:00','+57 300 100 1007','approved','crm','Dolor persistente','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(20,8,'Seguimiento #10',12,8,12,'2026-03-11 11:00:00','2026-03-11 11:30:00','+57 300 100 1008','approved','web','Chequeo anual','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(21,9,'Chequeo #11',2,9,9,'2026-03-11 14:00:00','2026-03-11 14:30:00','+57 300 100 1009','approved','whatsapp','Consulta rápida','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(22,10,'Teleconsulta #12',3,10,3,'2026-03-11 17:00:00','2026-03-11 17:30:00','+57 300 100 1010','pending','chatbot','Revisión integral','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(23,5,'Revisión #13',4,5,5,'2026-03-11 20:00:00','2026-03-11 20:30:00','+57 300 100 1005','rejected','crm','Control clínico','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(24,6,'Consulta Especializada #14',11,6,11,'2026-03-11 23:00:00','2026-03-11 23:30:00','+57 300 100 1006','completed','web','Validación de resultados','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(25,7,'Consulta General #15',12,7,7,'2026-03-12 02:00:00','2026-03-12 02:30:00','+57 300 100 1007','pending','whatsapp','Dolor persistente','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(26,8,'Control Mensual #16',2,8,2,'2026-03-12 05:00:00','2026-03-12 05:30:00','+57 300 100 1008','approved','chatbot','Chequeo anual','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(27,9,'Seguimiento #17',3,9,9,'2026-03-12 08:00:00','2026-03-12 08:30:00','+57 300 100 1009','approved','crm','Consulta rápida','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(28,10,'Chequeo #18',4,10,4,'2026-03-12 11:00:00','2026-03-12 11:30:00','+57 300 100 1010','approved','web','Revisión integral','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(29,5,'Teleconsulta #19',11,5,5,'2026-03-12 14:00:00','2026-03-12 14:30:00','+57 300 100 1005','pending','whatsapp','Control clínico','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(30,6,'Revisión #20',12,6,12,'2026-03-12 17:00:00','2026-03-12 17:30:00','+57 300 100 1006','rejected','chatbot','Validación de resultados','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(31,7,'Consulta Especializada #21',2,7,7,'2026-03-12 20:00:00','2026-03-12 20:30:00','+57 300 100 1007','completed','crm','Dolor persistente','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(32,8,'Consulta General #22',3,8,3,'2026-03-12 23:00:00','2026-03-12 23:30:00','+57 300 100 1008','pending','web','Chequeo anual','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(33,9,'Control Mensual #23',4,9,9,'2026-03-13 02:00:00','2026-03-13 02:30:00','+57 300 100 1009','approved','whatsapp','Consulta rápida','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(34,10,'Seguimiento #24',11,10,11,'2026-03-13 05:00:00','2026-03-13 05:30:00','+57 300 100 1010','approved','chatbot','Revisión integral','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(35,5,'Chequeo #25',12,5,5,'2026-03-13 08:00:00','2026-03-13 08:30:00','+57 300 100 1005','approved','crm','Control clínico','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(36,6,'Teleconsulta #26',2,6,2,'2026-03-13 11:00:00','2026-03-13 11:30:00','+57 300 100 1006','pending','web','Validación de resultados','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(37,7,'Revisión #27',3,7,7,'2026-03-13 14:00:00','2026-03-13 14:30:00','+57 300 100 1007','rejected','whatsapp','Dolor persistente','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(38,8,'Consulta Especializada #28',4,8,4,'2026-03-13 17:00:00','2026-03-13 17:30:00','+57 300 100 1008','completed','chatbot','Chequeo anual','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(39,9,'Consulta General #29',11,9,9,'2026-03-13 20:00:00','2026-03-13 20:30:00','+57 300 100 1009','pending','crm','Consulta rápida','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(40,10,'Control Mensual #30',12,10,12,'2026-03-13 23:00:00','2026-03-13 23:30:00','+57 300 100 1010','approved','web','Revisión integral','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(41,5,'Seguimiento #31',2,5,5,'2026-03-14 02:00:00','2026-03-14 02:30:00','+57 300 100 1005','approved','whatsapp','Control clínico','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(42,6,'Chequeo #32',3,6,3,'2026-03-14 05:00:00','2026-03-14 05:30:00','+57 300 100 1006','approved','chatbot','Validación de resultados','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(43,7,'Teleconsulta #33',4,7,7,'2026-03-14 08:00:00','2026-03-14 08:30:00','+57 300 100 1007','pending','crm','Dolor persistente','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(44,8,'Revisión #34',11,8,11,'2026-03-14 11:00:00','2026-03-14 11:30:00','+57 300 100 1008','rejected','web','Chequeo anual','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(45,9,'Consulta Especializada #35',12,9,9,'2026-03-14 14:00:00','2026-03-14 14:30:00','+57 300 100 1009','completed','whatsapp','Consulta rápida','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(46,10,'Consulta General #36',2,10,2,'2026-03-14 17:00:00','2026-03-14 17:30:00','+57 300 100 1010','pending','chatbot','Revisión integral','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(47,5,'Control Mensual #37',3,5,5,'2026-03-14 20:00:00','2026-03-14 20:30:00','+57 300 100 1005','approved','crm','Control clínico','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(48,6,'Seguimiento #38',4,6,4,'2026-03-14 23:00:00','2026-03-14 23:30:00','+57 300 100 1006','approved','web','Validación de resultados','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(49,7,'Chequeo #39',11,7,7,'2026-03-15 02:00:00','2026-03-15 02:30:00','+57 300 100 1007','approved','whatsapp','Dolor persistente','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(50,8,'Teleconsulta #40',12,8,12,'2026-03-15 05:00:00','2026-03-15 05:30:00','+57 300 100 1008','pending','chatbot','Chequeo anual','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(51,9,'Revisión #41',2,9,9,'2026-03-15 08:00:00','2026-03-15 08:30:00','+57 300 100 1009','rejected','crm','Consulta rápida','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(52,10,'Consulta Especializada #42',3,10,3,'2026-03-15 11:00:00','2026-03-15 11:30:00','+57 300 100 1010','completed','web','Revisión integral','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(53,5,'Consulta General #43',4,5,5,'2026-03-15 14:00:00','2026-03-15 14:30:00','+57 300 100 1005','pending','whatsapp','Control clínico','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(54,6,'Control Mensual #44',11,6,11,'2026-03-15 17:00:00','2026-03-15 17:30:00','+57 300 100 1006','approved','chatbot','Validación de resultados','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(55,7,'Seguimiento #45',12,7,7,'2026-03-15 20:00:00','2026-03-15 20:30:00','+57 300 100 1007','approved','crm','Dolor persistente','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(56,8,'Chequeo #46',2,8,2,'2026-03-15 23:00:00','2026-03-15 23:30:00','+57 300 100 1008','approved','web','Chequeo anual','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(57,9,'Teleconsulta #47',3,9,9,'2026-03-16 02:00:00','2026-03-16 02:30:00','+57 300 100 1009','pending','whatsapp','Consulta rápida','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(58,10,'Revisión #48',4,10,4,'2026-03-16 05:00:00','2026-03-16 05:30:00','+57 300 100 1010','rejected','chatbot','Revisión integral','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(59,5,'Consulta Especializada #49',11,5,5,'2026-03-16 08:00:00','2026-03-16 08:30:00','+57 300 100 1005','completed','crm','Control clínico','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(60,6,'Consulta General #50',12,6,12,'2026-03-16 11:00:00','2026-03-16 11:30:00','+57 300 100 1006','pending','web','Validación de resultados','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(61,7,'Control Mensual #51',2,7,7,'2026-03-16 14:00:00','2026-03-16 14:30:00','+57 300 100 1007','approved','whatsapp','Dolor persistente','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(62,8,'Seguimiento #52',3,8,3,'2026-03-16 17:00:00','2026-03-16 17:30:00','+57 300 100 1008','approved','chatbot','Chequeo anual','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(63,9,'Chequeo #53',4,9,9,'2026-03-16 20:00:00','2026-03-16 20:30:00','+57 300 100 1009','approved','crm','Consulta rápida','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(64,10,'Teleconsulta #54',11,10,11,'2026-03-16 23:00:00','2026-03-16 23:30:00','+57 300 100 1010','pending','web','Revisión integral','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(65,5,'Revisión #55',12,5,5,'2026-03-17 02:00:00','2026-03-17 02:30:00','+57 300 100 1005','rejected','whatsapp','Control clínico','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(66,6,'Consulta Especializada #56',2,6,2,'2026-03-17 05:00:00','2026-03-17 05:30:00','+57 300 100 1006','completed','chatbot','Validación de resultados','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(67,7,'Consulta General #57',3,7,7,'2026-03-17 08:00:00','2026-03-17 08:30:00','+57 300 100 1007','pending','crm','Dolor persistente','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(68,8,'Control Mensual #58',4,8,4,'2026-03-17 11:00:00','2026-03-17 11:30:00','+57 300 100 1008','approved','web','Chequeo anual','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(69,9,'Seguimiento #59',11,9,9,'2026-03-17 14:00:00','2026-03-17 14:30:00','+57 300 100 1009','approved','whatsapp','Consulta rápida','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(70,10,'Chequeo #60',12,10,12,'2026-03-17 17:00:00','2026-03-17 17:30:00','+57 300 100 1010','approved','chatbot','Revisión integral','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(71,5,'Teleconsulta #61',2,5,5,'2026-03-17 20:00:00','2026-03-17 20:30:00','+57 300 100 1005','pending','crm','Control clínico','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(72,6,'Revisión #62',3,6,3,'2026-03-17 23:00:00','2026-03-17 23:30:00','+57 300 100 1006','rejected','web','Validación de resultados','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(73,7,'Consulta Especializada #63',4,7,7,'2026-03-18 02:00:00','2026-03-18 02:30:00','+57 300 100 1007','completed','whatsapp','Dolor persistente','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(74,8,'Consulta General #64',11,8,11,'2026-03-18 05:00:00','2026-03-18 05:30:00','+57 300 100 1008','pending','chatbot','Chequeo anual','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(75,9,'Control Mensual #65',12,9,9,'2026-03-18 08:00:00','2026-03-18 08:30:00','+57 300 100 1009','approved','crm','Consulta rápida','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(76,10,'Seguimiento #66',2,10,2,'2026-03-18 11:00:00','2026-03-18 11:30:00','+57 300 100 1010','approved','web','Revisión integral','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(77,5,'Chequeo #67',3,5,5,'2026-03-18 14:00:00','2026-03-18 14:30:00','+57 300 100 1005','approved','whatsapp','Control clínico','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(78,6,'Teleconsulta #68',4,6,4,'2026-03-18 17:00:00','2026-03-18 17:30:00','+57 300 100 1006','pending','chatbot','Validación de resultados','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(79,7,'Revisión #69',11,7,7,'2026-03-18 20:00:00','2026-03-18 20:30:00','+57 300 100 1007','rejected','crm','Dolor persistente','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(80,8,'Consulta Especializada #70',12,8,12,'2026-03-18 23:00:00','2026-03-18 23:30:00','+57 300 100 1008','completed','web','Chequeo anual','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(81,9,'Consulta General #71',2,9,9,'2026-03-19 02:00:00','2026-03-19 02:30:00','+57 300 100 1009','pending','whatsapp','Consulta rápida','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(82,10,'Control Mensual #72',3,10,3,'2026-03-19 05:00:00','2026-03-19 05:30:00','+57 300 100 1010','approved','chatbot','Revisión integral','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(83,5,'Seguimiento #73',4,5,5,'2026-03-19 08:00:00','2026-03-19 08:30:00','+57 300 100 1005','approved','crm','Control clínico','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(84,6,'Chequeo #74',11,6,11,'2026-03-19 11:00:00','2026-03-19 11:30:00','+57 300 100 1006','approved','web','Validación de resultados','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(85,7,'Teleconsulta #75',12,7,7,'2026-03-19 14:00:00','2026-03-19 14:30:00','+57 300 100 1007','pending','whatsapp','Dolor persistente','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(86,8,'Revisión #76',2,8,2,'2026-03-19 17:00:00','2026-03-19 17:30:00','+57 300 100 1008','rejected','chatbot','Chequeo anual','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(87,9,'Consulta Especializada #77',3,9,9,'2026-03-19 20:00:00','2026-03-19 20:30:00','+57 300 100 1009','completed','crm','Consulta rápida','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(88,10,'Consulta General #78',4,10,4,'2026-03-19 23:00:00','2026-03-19 23:30:00','+57 300 100 1010','pending','web','Revisión integral','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(89,5,'Control Mensual #79',11,5,5,'2026-03-20 02:00:00','2026-03-20 02:30:00','+57 300 100 1005','approved','whatsapp','Control clínico','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled'),(90,6,'Seguimiento #80',12,6,12,'2026-03-20 05:00:00','2026-03-20 05:30:00','+57 300 100 1006','approved','chatbot','Validación de resultados','2026-07-11 09:15:28',0,'unconfirmed',NULL,NULL,50.00,1,0,NULL,'scheduled');
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `care_pathways`
--

DROP TABLE IF EXISTS `care_pathways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `care_pathways` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `condition_type` varchar(50) NOT NULL,
  `duration_days` int DEFAULT '14',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `care_pathways`
--

LOCK TABLES `care_pathways` WRITE;
/*!40000 ALTER TABLE `care_pathways` DISABLE KEYS */;
INSERT INTO `care_pathways` VALUES (1,'Protocolo Lumbalgia Mecánica Test','lumbalgia',14,'2026-07-22 03:20:49');
/*!40000 ALTER TABLE `care_pathways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cfdi_invoices`
--

DROP TABLE IF EXISTS `cfdi_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cfdi_invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `appointment_id` int DEFAULT NULL,
  `patient_id` int NOT NULL,
  `folio_fiscal` varchar(64) DEFAULT NULL,
  `serie` varchar(10) DEFAULT 'F',
  `folio` int NOT NULL DEFAULT '1001',
  `subtotal` decimal(10,2) NOT NULL,
  `iva` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total` decimal(10,2) NOT NULL,
  `status` varchar(20) DEFAULT 'draft',
  `pdf_path` varchar(255) DEFAULT NULL,
  `xml_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  KEY `folio` (`folio`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cfdi_invoices`
--

LOCK TABLES `cfdi_invoices` WRITE;
/*!40000 ALTER TABLE `cfdi_invoices` DISABLE KEYS */;
INSERT INTO `cfdi_invoices` VALUES (1,1,5,'66641108-4ee0-4049-9b02-e85e7483bf96','F',1001,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:10:22'),(2,1,5,'e1417fb1-d441-46c9-a849-b7390876ba79','F',1002,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:10:26'),(3,1,5,'f03632bc-6bab-47d6-aa20-85918d0d16d5','F',1003,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:10:27'),(4,1,5,'f9de06b3-a709-4751-bd7a-dd3945579b28','F',1004,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:11:16'),(5,1,5,'6c5d68aa-e763-4c0c-b74f-38706ef755bb','F',1005,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:12:49'),(6,1,5,'b6050bc9-3be3-4f04-9fa0-6cd15eb873c2','F',1006,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:13:25'),(7,1,5,'0264eadd-da4a-4674-bab7-3f2a5242946c','F',1007,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:13:37'),(8,1,5,'cb0fc514-262f-4f14-acf7-bb1b51d48641','F',1008,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:13:43'),(9,1,5,'39fa486d-24b7-483f-8d1f-92198a179d08','F',1009,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:13:50'),(10,1,5,'bfc21d3d-8bd5-462d-8858-d8e088db4166','F',1010,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:13:59'),(11,1,5,'640b7fac-7a3c-4552-a1fe-2e2381eadb98','F',1011,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:14:07'),(12,1,5,'16a8997e-b052-416a-817d-30201c0dba7b','F',1012,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:14:53'),(13,1,5,'871b2bb9-c1f1-4a85-9815-32739574f1dd','F',1013,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:20:01'),(14,1,5,'7595b366-7f4c-436d-a06a-ad1b0adbc96d','F',1014,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:20:34'),(15,1,5,'7d426d23-0cfe-403c-ba5f-9cc5b9170f17','F',1015,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:20:42'),(16,1,5,'f6113423-01e8-4675-9b0a-f040e94f30c1','F',1016,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:20:49'),(17,1,5,'ebd8e40c-46f6-4d7b-8624-6b758feb8b98','F',1017,850.00,0.00,850.00,'stamped',NULL,NULL,'2026-07-22 03:20:58');
/*!40000 ALTER TABLE `cfdi_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_messages`
--

DROP TABLE IF EXISTS `chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender_id` int NOT NULL,
  `receiver_id` int NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `sender_id` (`sender_id`),
  KEY `receiver_id` (`receiver_id`),
  CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`),
  CONSTRAINT `chat_messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_messages`
--

LOCK TABLES `chat_messages` WRITE;
/*!40000 ALTER TABLE `chat_messages` DISABLE KEYS */;
INSERT INTO `chat_messages` VALUES (9,5,2,'Hola doctor, quiero cambiar la hora','2026-07-11 09:15:27'),(10,2,5,'Perfecto, te muevo a las 10:30','2026-07-11 09:15:27'),(11,6,3,'Tengo una pregunta de mi receta','2026-07-11 09:15:27'),(12,3,6,'Te respondo en unos minutos','2026-07-11 09:15:27'),(13,7,4,'¿La consulta sigue confirmada?','2026-07-11 09:15:27'),(14,4,7,'Sí, nos vemos hoy','2026-07-11 09:15:27'),(15,8,11,'Necesito una teleconsulta','2026-07-11 09:15:27'),(16,11,8,'Listo, te agendo para mañana','2026-07-11 09:15:27'),(17,9,12,'Quiero revisión general','2026-07-11 09:15:27'),(18,12,9,'Te comparto horarios disponibles','2026-07-11 09:15:27');
/*!40000 ALTER TABLE `chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cicatrices`
--

DROP TABLE IF EXISTS `cicatrices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cicatrices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expediente_id` int NOT NULL,
  `presenta` tinyint(1) NOT NULL DEFAULT '0',
  `sitio` varchar(255) DEFAULT NULL,
  `queloide` enum('si','no','null') DEFAULT 'null',
  `retractil` enum('si','no','null') DEFAULT 'null',
  `abierta` enum('si','no','null') DEFAULT 'null',
  `con_adherencia` enum('si','no','null') DEFAULT 'null',
  `hipertrofica` enum('si','no','null') DEFAULT 'null',
  PRIMARY KEY (`id`),
  UNIQUE KEY `expediente_id` (`expediente_id`),
  CONSTRAINT `cicatrices_ibfk_1` FOREIGN KEY (`expediente_id`) REFERENCES `expedientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cicatrices`
--

LOCK TABLES `cicatrices` WRITE;
/*!40000 ALTER TABLE `cicatrices` DISABLE KEYS */;
INSERT INTO `cicatrices` VALUES (1,1,1,'Abdomen anterior','no','si','no','si','no');
/*!40000 ALTER TABLE `cicatrices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clinic_resources`
--

DROP TABLE IF EXISTS `clinic_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinic_resources` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(50) DEFAULT 'cubiculo',
  `status` varchar(20) DEFAULT 'available',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `clinic_id` int DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clinic_resources`
--

LOCK TABLES `clinic_resources` WRITE;
/*!40000 ALTER TABLE `clinic_resources` DISABLE KEYS */;
INSERT INTO `clinic_resources` VALUES (1,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','maintenance','2026-07-22 03:11:15',1),(2,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','available','2026-07-22 03:11:17',1),(3,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','available','2026-07-22 03:12:50',1),(4,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','available','2026-07-22 03:13:25',1),(5,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','available','2026-07-22 03:13:38',1),(6,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','available','2026-07-22 03:13:43',1),(7,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','available','2026-07-22 03:13:50',1),(8,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','available','2026-07-22 03:13:59',1),(9,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','available','2026-07-22 03:14:07',1),(10,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','available','2026-07-22 03:14:53',1),(11,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','available','2026-07-22 03:20:01',1),(12,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','available','2026-07-22 03:20:34',1),(13,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','available','2026-07-22 03:20:43',1),(14,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','available','2026-07-22 03:20:49',1),(15,'Cubículo 1 (Electroterapia & Ultrasonido)','cubiculo','available','2026-07-22 03:20:58',1);
/*!40000 ALTER TABLE `clinic_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clinics`
--

DROP TABLE IF EXISTS `clinics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `code` varchar(30) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clinics`
--

LOCK TABLES `clinics` WRITE;
/*!40000 ALTER TABLE `clinics` DISABLE KEYS */;
INSERT INTO `clinics` VALUES (1,'Clínica Central (CDMX)','CDMX-CENTRAL','Av. Insurgentes Sur 1200, CDMX','5551234567','2026-07-22 03:19:50');
/*!40000 ALTER TABLE `clinics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dolor_puntos`
--

DROP TABLE IF EXISTS `dolor_puntos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dolor_puntos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expediente_id` int NOT NULL,
  `region` varchar(50) NOT NULL,
  `vista` varchar(20) NOT NULL DEFAULT 'anterior',
  `eva_nivel` int NOT NULL DEFAULT '5',
  `tipo_dolor` varchar(50) DEFAULT 'sordo',
  `notas` varchar(255) DEFAULT NULL,
  `pos_x` float NOT NULL,
  `pos_y` float NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `expediente_id` (`expediente_id`),
  CONSTRAINT `dolor_puntos_ibfk_1` FOREIGN KEY (`expediente_id`) REFERENCES `expedientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dolor_puntos`
--

LOCK TABLES `dolor_puntos` WRITE;
/*!40000 ALTER TABLE `dolor_puntos` DISABLE KEYS */;
INSERT INTO `dolor_puntos` VALUES (29,1,'Hombro Derecho','anterior',7,'Punzante','Al abducir el brazo',35.5,28.2,'2026-07-22 03:20:57'),(30,1,'Zona Lumbar','posterior',9,'Opresivo','Post-ejercicio',50,52,'2026-07-22 03:20:57');
/*!40000 ALTER TABLE `dolor_puntos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expedientes`
--

DROP TABLE IF EXISTS `expedientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expedientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `status` enum('draft','complete') NOT NULL DEFAULT 'draft',
  `eva_dolor` int DEFAULT NULL,
  `notas_generales` text,
  `notas_plan` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `clinic_id` int DEFAULT '1',
  `soap_subjetivo` text,
  `soap_objetivo` text,
  `soap_analisis` text,
  `soap_plan` text,
  `icd10_tags` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `expedientes_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expedientes`
--

LOCK TABLES `expedientes` WRITE;
/*!40000 ALTER TABLE `expedientes` DISABLE KEYS */;
INSERT INTO `expedientes` VALUES (1,5,'draft',8,'Dolor lumbar severo',NULL,'2026-07-11 10:14:37','2026-07-22 03:09:48',1,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `expedientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exploraciones`
--

DROP TABLE IF EXISTS `exploraciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exploraciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expediente_id` int NOT NULL,
  `estatura_cm` int DEFAULT NULL,
  `peso_kg` decimal(5,2) DEFAULT NULL,
  `fc` int DEFAULT NULL,
  `fr` int DEFAULT NULL,
  `ta` varchar(20) DEFAULT NULL,
  `arcos_movimiento` text,
  `fuerza_muscular` text,
  `marcha_descriptiva` text,
  `reflejos` text,
  `sensibilidad` text,
  `lenguaje_orientacion` text,
  `otros` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `expediente_id` (`expediente_id`),
  CONSTRAINT `exploraciones_ibfk_1` FOREIGN KEY (`expediente_id`) REFERENCES `expedientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exploraciones`
--

LOCK TABLES `exploraciones` WRITE;
/*!40000 ALTER TABLE `exploraciones` DISABLE KEYS */;
INSERT INTO `exploraciones` VALUES (1,1,175,78.50,72,16,'120/80','Rangos completos','5/5 general',NULL,'Normales','Conservada','Orientado en 3 esferas','Sin observaciones adicionales');
/*!40000 ALTER TABLE `exploraciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_transactions`
--

DROP TABLE IF EXISTS `financial_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `financial_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `appointment_id` int DEFAULT NULL,
  `patient_id` int NOT NULL,
  `doctor_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `doctor_commission_amount` decimal(10,2) NOT NULL,
  `clinic_net_amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT 'cash',
  `payment_status` varchar(20) DEFAULT 'paid',
  `transaction_ref` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_transactions`
--

LOCK TABLES `financial_transactions` WRITE;
/*!40000 ALTER TABLE `financial_transactions` DISABLE KEYS */;
INSERT INTO `financial_transactions` VALUES (1,1,5,2,1200.00,720.00,480.00,'card','paid','TX-TEST-1001','2026-07-22 03:20:49'),(2,1,5,2,1200.00,720.00,480.00,'card','paid','TX-TEST-1001','2026-07-22 03:20:58');
/*!40000 ALTER TABLE `financial_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marchas`
--

DROP TABLE IF EXISTS `marchas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marchas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expediente_id` int NOT NULL,
  `libre` tinyint(1) DEFAULT '0',
  `claudicante` tinyint(1) DEFAULT '0',
  `con_ayuda` tinyint(1) DEFAULT '0',
  `espasticas` tinyint(1) DEFAULT '0',
  `ataxica` tinyint(1) DEFAULT '0',
  `otros` tinyint(1) DEFAULT '0',
  `otros_spec` varchar(255) DEFAULT NULL,
  `observaciones` text,
  `inicio_marcha` tinyint DEFAULT NULL,
  `paso_pd_longitud` tinyint DEFAULT NULL,
  `paso_pd_altura` tinyint DEFAULT NULL,
  `paso_pi_longitud` tinyint DEFAULT NULL,
  `paso_pi_altura` tinyint DEFAULT NULL,
  `simetria_paso` tinyint DEFAULT NULL,
  `continuidad_pasos` tinyint DEFAULT NULL,
  `trayectoria` tinyint DEFAULT NULL,
  `tronco` tinyint DEFAULT NULL,
  `postura_marcha` tinyint DEFAULT NULL,
  `total_balance_manual` tinyint DEFAULT NULL,
  `total_marcha` tinyint DEFAULT NULL,
  `total_general` tinyint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `expediente_id` (`expediente_id`),
  CONSTRAINT `marchas_ibfk_1` FOREIGN KEY (`expediente_id`) REFERENCES `expedientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marchas`
--

LOCK TABLES `marchas` WRITE;
/*!40000 ALTER TABLE `marchas` DISABLE KEYS */;
INSERT INTO `marchas` VALUES (1,1,1,0,0,0,0,0,'','Marcha fluida',1,1,1,1,1,1,1,2,2,1,10,12,22);
/*!40000 ALTER TABLE `marchas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `padecimientos`
--

DROP TABLE IF EXISTS `padecimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `padecimientos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expediente_id` int NOT NULL,
  `motivo_consulta` text,
  `inicio` text,
  `evolucion` text,
  `estudios` text,
  `tratamientos_previos` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `expediente_id` (`expediente_id`),
  CONSTRAINT `padecimientos_ibfk_1` FOREIGN KEY (`expediente_id`) REFERENCES `expedientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `padecimientos`
--

LOCK TABLES `padecimientos` WRITE;
/*!40000 ALTER TABLE `padecimientos` DISABLE KEYS */;
INSERT INTO `padecimientos` VALUES (1,1,'Dolor lumbar crónico','Hace 3 meses tras levantar carga','Progresivo','Resonancia lumbar sin hernia','Analgésicos');
/*!40000 ALTER TABLE `padecimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_files`
--

DROP TABLE IF EXISTS `patient_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_files` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `dob` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `blood_type` varchar(10) DEFAULT NULL,
  `allergies` text,
  `medical_history` text,
  `medications` text,
  `clinical_notes` text,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `patient_id` (`patient_id`),
  CONSTRAINT `patient_files_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_files`
--

LOCK TABLES `patient_files` WRITE;
/*!40000 ALTER TABLE `patient_files` DISABLE KEYS */;
INSERT INTO `patient_files` VALUES (1,5,'1985-05-15','Avenida Principal 123','O+','Penicilina y mariscos','Hipertensión arterial controlada','Losartán 50mg diario','Paciente refiere sentirse bien hoy. Presión arterial dentro del rango normal.','2026-07-11 09:44:57'),(2,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-11 09:45:30'),(3,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-11 09:45:30'),(4,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-11 09:45:30'),(5,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-11 09:45:30'),(6,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-11 09:45:30');
/*!40000 ALTER TABLE `patient_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_fiscal_profiles`
--

DROP TABLE IF EXISTS `patient_fiscal_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_fiscal_profiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `rfc` varchar(13) NOT NULL,
  `razon_social` varchar(255) NOT NULL,
  `codigo_postal` varchar(10) NOT NULL,
  `regimen_fiscal` varchar(10) NOT NULL DEFAULT '605',
  `uso_cfdi` varchar(10) NOT NULL DEFAULT 'D01',
  `email_cfdi` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `patient_id` (`patient_id`),
  CONSTRAINT `patient_fiscal_profiles_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_fiscal_profiles`
--

LOCK TABLES `patient_fiscal_profiles` WRITE;
/*!40000 ALTER TABLE `patient_fiscal_profiles` DISABLE KEYS */;
INSERT INTO `patient_fiscal_profiles` VALUES (1,5,'PEPA900101XYZ','Pepe Paciente Renovado S.A. de C.V.','06600','605','D01','pepe.facturacion@doctoria.com','2026-07-22 03:10:22');
/*!40000 ALTER TABLE `patient_fiscal_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_prescriptions`
--

DROP TABLE IF EXISTS `patient_prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_prescriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `pathway_id` int NOT NULL,
  `start_date` date NOT NULL,
  `status` varchar(20) DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_prescriptions`
--

LOCK TABLES `patient_prescriptions` WRITE;
/*!40000 ALTER TABLE `patient_prescriptions` DISABLE KEYS */;
INSERT INTO `patient_prescriptions` VALUES (1,5,1,'2026-07-22','active','2026-07-22 03:20:49'),(2,5,1,'2026-07-22','active','2026-07-22 03:20:58');
/*!40000 ALTER TABLE `patient_prescriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_links`
--

DROP TABLE IF EXISTS `payment_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_links` (
  `id` int NOT NULL AUTO_INCREMENT,
  `appointment_id` int NOT NULL,
  `token` varchar(64) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_links`
--

LOCK TABLES `payment_links` WRITE;
/*!40000 ALTER TABLE `payment_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plan_sesiones`
--

DROP TABLE IF EXISTS `plan_sesiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan_sesiones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expediente_id` int NOT NULL,
  `fecha` date DEFAULT NULL,
  `indicaciones` text,
  `orden` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `expediente_id` (`expediente_id`),
  CONSTRAINT `plan_sesiones_ibfk_1` FOREIGN KEY (`expediente_id`) REFERENCES `expedientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plan_sesiones`
--

LOCK TABLES `plan_sesiones` WRITE;
/*!40000 ALTER TABLE `plan_sesiones` DISABLE KEYS */;
INSERT INTO `plan_sesiones` VALUES (69,1,'2026-07-12','Compresa húmeda caliente + TENS 15 min',0),(70,1,'2026-07-15','Masaje terapéutico + Ejercicios Williams',1);
/*!40000 ALTER TABLE `plan_sesiones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `problemas`
--

DROP TABLE IF EXISTS `problemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `problemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `expediente_id` int NOT NULL,
  `item_key` varchar(100) NOT NULL,
  `severidad` enum('leve','moderado','severo','na','null') DEFAULT 'null',
  `nota` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_exp_prob` (`expediente_id`,`item_key`),
  CONSTRAINT `problemas_ibfk_1` FOREIGN KEY (`expediente_id`) REFERENCES `expedientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `problemas`
--

LOCK TABLES `problemas` WRITE;
/*!40000 ALTER TABLE `problemas` DISABLE KEYS */;
INSERT INTO `problemas` VALUES (1,1,'dolor','moderado','Zona lumbar'),(2,1,'contractura','leve','Paravertebrales');
/*!40000 ALTER TABLE `problemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `role` enum('admin','medico','cliente') NOT NULL DEFAULT 'cliente',
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `ocupacion` varchar(255) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `sexo` enum('Femenino','Masculino','Otro') DEFAULT NULL,
  `estado_civil` enum('Soltero(a)','Casado(a)','Union libre','Divorciado(a)','Viudo(a)') DEFAULT NULL,
  `domicilio` text,
  `tel` varchar(40) DEFAULT NULL,
  `cel` varchar(40) DEFAULT NULL,
  `familiar_responsable` varchar(255) DEFAULT NULL,
  `familiar_tel` varchar(40) DEFAULT NULL,
  `familiar_cel` varchar(40) DEFAULT NULL,
  `default_commission_rate` decimal(5,2) DEFAULT '50.00',
  `clinic_id` int DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrador CRM','admin@doctoria.com','+57 300 100 0001','admin','$2y$10$tVSnX2zI2NsGXraojhDXZe3qI0HuQ1.UsQDl8nDdVY87l0cBQRfY2','2026-07-11 09:13:30',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(2,'Dr. Gregory House','house@doctoria.com','+57 300 100 0002','medico','$2y$10$tVSnX2zI2NsGXraojhDXZe3qI0HuQ1.UsQDl8nDdVY87l0cBQRfY2','2026-07-11 09:13:30',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(3,'Dra. Elena Torres','elena@doctoria.com','+57 300 100 0003','medico','$2y$10$tVSnX2zI2NsGXraojhDXZe3qI0HuQ1.UsQDl8nDdVY87l0cBQRfY2','2026-07-11 09:13:30',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(4,'Dr. Alfredo Hidalgo','alfredo@doctoria.com','+57 300 100 0004','medico','$2y$10$tVSnX2zI2NsGXraojhDXZe3qI0HuQ1.UsQDl8nDdVY87l0cBQRfY2','2026-07-11 09:13:30',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(5,'Pepe Paciente Renovado','pepe@doctoria.com','555123456','cliente','$2y$10$tVSnX2zI2NsGXraojhDXZe3qI0HuQ1.UsQDl8nDdVY87l0cBQRfY2','2026-07-11 09:13:30',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(6,'Ana Suarez','ana@doctoria.com','+57 300 100 0006','cliente','$2y$10$tVSnX2zI2NsGXraojhDXZe3qI0HuQ1.UsQDl8nDdVY87l0cBQRfY2','2026-07-11 09:13:30',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(7,'Carlos Rivas','carlos@doctoria.com','+57 300 100 0007','cliente','$2y$10$tVSnX2zI2NsGXraojhDXZe3qI0HuQ1.UsQDl8nDdVY87l0cBQRfY2','2026-07-11 09:13:30',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(8,'Marta Perez','marta@doctoria.com','+57 300 100 0008','cliente','$2y$10$tVSnX2zI2NsGXraojhDXZe3qI0HuQ1.UsQDl8nDdVY87l0cBQRfY2','2026-07-11 09:13:30',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(9,'Lucia Mendez','lucia@doctoria.com','+57 300 100 0009','cliente','$2y$10$tVSnX2zI2NsGXraojhDXZe3qI0HuQ1.UsQDl8nDdVY87l0cBQRfY2','2026-07-11 09:15:27',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(10,'Jorge Almanza','jorge@doctoria.com','+57 300 100 0010','cliente','$2y$10$tVSnX2zI2NsGXraojhDXZe3qI0HuQ1.UsQDl8nDdVY87l0cBQRfY2','2026-07-11 09:15:27',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(11,'Dra. Sofia Rosales','sofia@doctoria.com','+57 300 100 0011','medico','$2y$10$tVSnX2zI2NsGXraojhDXZe3qI0HuQ1.UsQDl8nDdVY87l0cBQRfY2','2026-07-11 09:15:27',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(12,'Dr. Juan Pardo','juan@doctoria.com','+57 300 100 0012','medico','$2y$10$tVSnX2zI2NsGXraojhDXZe3qI0HuQ1.UsQDl8nDdVY87l0cBQRfY2','2026-07-11 09:15:27',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(16,'Updated Test User','test_crud_1783762779@example.com','+57 300 999 9999','medico','$2y$10$EyNW6Glxnfz0aDXrr5x7ceTcWyPVEthWFXL5Eg.j9xsqw3Zh2p4C2','2026-07-11 09:39:40',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(17,'Updated Test User','test_crud_1783763100@example.com','+57 300 999 9999','medico','$2y$10$8LQhA4YFtAqBFHAxqDaW9.IZ6mbQwX2DgCVPg6vxWe/xqK9UvefFK','2026-07-11 09:45:01',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(18,'Updated Test User','test_crud_1783919036@example.com','+57 300 999 9999','medico','$2y$10$yO24BcNGP6uIPSKS7G1X0eI.0pdq8JIWgrC.vIiaPoLhu0AW98LJe','2026-07-13 05:03:56',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(19,'Updated Test User','test_crud_1783920341@example.com','+57 300 999 9999','medico','$2y$10$qyYa17sqkkBzauNaRtExJ.ZxhZrng/iMIm5.pgCZugs0o2YxBiwqa','2026-07-13 05:25:41',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(20,'Updated Test User','test_crud_1783950036@example.com','+57 300 999 9999','medico','$2y$10$9iG.YdqFC74ux99IGq/2yOzhv/jfN4reqOeYzatWsUpX5y0ALyJSW','2026-07-13 13:40:36',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(21,'Updated Test User','test_crud_1783953668@example.com','+57 300 999 9999','medico','$2y$10$XAxxWxn7niXVEvYNWL9MPuDpRuXqvivIxl8s3vCYmmD2qzwjz9iwG','2026-07-13 14:41:08',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(22,'Updated Test User','test_crud_1783957720@example.com','+57 300 999 9999','medico','$2y$10$yqrGw/rr13nob.T5cKaNFOOg0UqwsMuXOAs/rYE0TgHFzosKR509m','2026-07-13 15:48:41',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(23,'Updated Test User','test_crud_1783957813@example.com','+57 300 999 9999','medico','$2y$10$enDmfayJIMXBpv.erP.4teNWmZQrDyX.P6bWqF1DFtA6CFoBl3cFC','2026-07-13 15:50:14',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(24,'Updated Test User','test_crud_1783957878@example.com','+57 300 999 9999','medico','$2y$10$vePkbOz6fTL3vWSt4h65aezojfoZppeWJEVzFo6lX9xjw.dgrurB6','2026-07-13 15:51:18',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(25,'Updated Test User','test_crud_1783957891@example.com','+57 300 999 9999','medico','$2y$10$94JWjf2Q3b8P0V8ZE2JmLelnGRqOelljrP5MOorynajOj7/B.7syq','2026-07-13 15:51:31',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(26,'Updated Test User','test_crud_1783958023@example.com','+57 300 999 9999','medico','$2y$10$mr/P4YujYNR5a8fTThzNr.l0WmNJkq5T1wasFMstsUCoovcoFIvLy','2026-07-13 15:53:43',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(27,'Updated Test User','test_crud_1783958036@example.com','+57 300 999 9999','medico','$2y$10$uwyjmQUlS5sfY9RbmM4PreXVgGdBu55T3QsdB2hTmid/a.L8CvEWW','2026-07-13 15:53:56',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(28,'Updated Test User','test_crud_1783958121@example.com','+57 300 999 9999','medico','$2y$10$Pl1vqkrToA8pDYPb6eVwXOHXOSxk2RAxoG1LyRES/fItqDfKuBtry','2026-07-13 15:55:21',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(29,'Updated Test User','test_crud_1783958127@example.com','+57 300 999 9999','medico','$2y$10$BOSDj6lxCINacl4wXypwcetuGwApDkrkVgnhQae6zcQ5dShMZuuHe','2026-07-13 15:55:27',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(30,'Updated Test User','test_crud_1783958190@example.com','+57 300 999 9999','medico','$2y$10$CXvlYqpxu7yJyzsupWgd.eMCgq8aLOZpCBHN05j/D7GaZibQLe7Di','2026-07-13 15:56:30',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1),(31,'Updated Test User','test_crud_1784414754@example.com','+57 300 999 9999','medico','$2y$10$YJS8tQt/a3fTZ64g1Gt2KOLMQRQcGPIppZF9dgTPo5OghFh8hqHVS','2026-07-18 22:45:54',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50.00,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-22  3:21:02
